
function collatz(numero){
  numero = (numero%2) === 0  ?  numero/2 : numero*3 + 1
  return numero
} 

export function contar(respuesta){
  let nuevoNum = collatz(respuesta)
  console.log('')
  console.log('-----------------------------------------')
  console.log(' 1  *   Collatz Nro: ' + nuevoNum)
  console.log('-----------------------------------------')

  for (let i = 2 ; nuevoNum != 1; i++){
    nuevoNum = collatz(nuevoNum)
    console.log(` ${i}  *   Collatz Nro: ${nuevoNum}  `)
    console.log('-----------------------------------------')  
  }
}


