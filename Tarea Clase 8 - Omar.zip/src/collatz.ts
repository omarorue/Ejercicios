import { contar } from "./Tarea Clase 8/collatz"

const readline = require('readline')

let interfazCaptura = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})

console.log('')

interfazCaptura.question(' Ingrese un numero: ', (respuesta)=> {
  interfazCaptura.close()
  respuesta < 1 ? console.log ('Debe ingresar un numero positivo ! !') : contar(respuesta)
})